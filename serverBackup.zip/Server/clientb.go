package main

import (
	"log"
	"net"
)

func main() {

	conn, err := net.Dial("tcp", "localhost:8080")
	if err != nil {
		log.Println("Dial error:", err)
		return
	}
	defer conn.Close()
	log.Println("Je suis connecté")
	buffer := make([]byte, 128)

	for {
		_, err = conn.Read(buffer)
		if err != nil {
			log.Fatal("Read error", err)
		}
		switch buffer[0] {
		case 0:
			log.Println("Je suis le joueur", buffer[1])
		case 1:
			log.Println("Le joueur 2 c'est connecté")
		}
	}
}
